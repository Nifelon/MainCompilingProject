using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "ContextMenuData", menuName = "Data/Context Menu/Definition")]
public class ContextMenuData : ScriptableObject
{
    public ObjectType objectType;
    public List<ContextMenuOption> actions;
}