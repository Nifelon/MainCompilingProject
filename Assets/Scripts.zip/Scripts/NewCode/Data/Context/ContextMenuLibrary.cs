using System.Collections.Generic;
using UnityEngine;

public class ContextMenuLibrary : MonoBehaviour
{
    public static ContextMenuLibrary Instance;

    private Dictionary<ObjectType, ContextMenuData> menuLookup;

    [SerializeField] private List<ContextMenuData> menus = new(); // ����������� ������ � ����������

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            BuildLookup();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void BuildLookup()
    {
        menuLookup = new();

        foreach (var menu in menus)
        {
            if (!menuLookup.ContainsKey(menu.objectType))
            {
                menuLookup.Add(menu.objectType, menu);
            }
            else
            {
                Debug.LogWarning($"Duplicate menu for object type: {menu.objectType}");
            }
        }
    }

    public ContextMenuData GetMenu(ObjectType type)
    {
        if (menuLookup.TryGetValue(type, out var menu))
            return menu;

        Debug.LogWarning($"No context menu found for type: {type}");
        return null;
    }
}