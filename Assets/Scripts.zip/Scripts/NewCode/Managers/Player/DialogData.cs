using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class DialogButtonOption
{
    public string label;
    public DialogAction action;
    public DialogButtonType condition;
}

[CreateAssetMenu(fileName = "DialogData", menuName = "Data/DialogData")]
public class DialogData : ScriptableObject
{
    public List<DialogButtonOption> options;
}
