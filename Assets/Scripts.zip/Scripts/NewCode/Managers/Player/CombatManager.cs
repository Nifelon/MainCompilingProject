﻿using System.Collections.Generic;
using UnityEngine;
using static ObjectManager;

public class CombatManager : MonoBehaviour
{
    private SkillsData selectedSkill;

    public static CombatManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public bool isAwaitingAttackTarget = false;
    private List<Vector2Int> currentAttackZone = new();
    private Vector2Int currentAttackOrigin;

    /// <summary>
    /// Показывает зону атаки и переходит в режим выбора цели
    /// </summary>
    public void PrepareAttack(Vector2Int origin, SkillsData skill)
    {
        currentAttackOrigin = origin;
        if (skill.requiresTarget)
        {
            Debug.Log(skill.radius);
            currentAttackZone = GetAttackArea(origin, skill.radius);
            Debug.Log(currentAttackZone.Count);
            ShowAttackZone(origin, skill.radius);
            isAwaitingAttackTarget = true;
            selectedSkill = skill;
        }
        else
        {
            for (int x = -skill.radius; x <= skill.radius; x++)
                for (int y = -skill.radius; y <= skill.radius; y++)
                {
                    Vector2Int offset= new Vector2Int(x, y);
                    if (offset == Vector2Int.zero)
                        continue;
                    Debug.Log($"🗡️ Атака по клетке {offset+origin} из позиции {currentAttackOrigin}");
                    if (skill == null)
                        Debug.Log("No skill");
                    int damage = Random.Range(skill.minDamage, skill.maxDamage + 1);
                    DamageObjectAt(offset+origin, damage);
                }
            //GlobalCore.Instance.PlayerManager.SetSkillOnCooldown(selectedSkill);
            TurnManager.Instance.AdvanceTurn();
            Debug.Log("Work1");
            if (selectedSkill == null)
                Debug.Log("No Initializate");
            GlobalCore.Instance.PlayerSkillManager.skillCooldowns[skill] = Mathf.CeilToInt(skill.cooldown);
            Debug.Log("Work2");
            GlobalCore.Instance.PlayerSkillManager.UpdateCooldownUI();
        }
    }
    public void ShowAttackZone(Vector2Int center, int radius)
    {
        GlobalCore.Instance.PoolManagerHighLight.ReturnAllHighlights();

        List<Vector2Int> cells = GetAttackArea(center,radius);
        foreach (var cell in cells)
        {
            GameObject tile = GlobalCore.Instance.PoolManagerHighLight.GetHighlightTile();
            tile.transform.localPosition = new Vector3(cell.x, cell.y, -0.5f);
            tile.SetActive(true);
            GlobalCore.Instance.PoolManagerHighLight.activeHighlights.Add(tile);
        }
    }

    private List<Vector2Int> GetAttackArea(Vector2Int center, int radius)
    {
        List<Vector2Int> cells = new();

        // Простой радиус 1 (крест или квадрат)
        for (int x = -radius; x <= radius; x++)
        {
            for (int y = -radius; y <= radius; y++)
            {
                Vector2Int offset = new(x, y);
                if (offset != Vector2Int.zero) // не включаем центр
                    cells.Add(center + offset);
            }
        }

        return cells;
    }
    void Update()
    {
        if (!isAwaitingAttackTarget) return;

        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mouseWorld2D = new(mouseWorldPos.x, mouseWorldPos.y);

            RaycastHit2D hit = Physics2D.Raycast(mouseWorld2D, Vector2.zero);

            if (hit.collider != null)
            {
                Vector2Int clickedCell = new(
                    Mathf.RoundToInt(hit.collider.transform.localPosition.x),
                    Mathf.RoundToInt(hit.collider.transform.localPosition.y)
                );

                if (currentAttackZone.Contains(clickedCell))
                {
                    ExecuteAttack(clickedCell);
                    GlobalCore.Instance.PoolManagerHighLight.ReturnAllHighlights();
                    isAwaitingAttackTarget = false;
                    selectedSkill = null;
                }
                else
                {
                    Debug.Log("Клик вне зоны атаки!");
                }
            }
        }
    }
    private void ExecuteAttack(Vector2Int targetCell)
    {
        if (selectedSkill == null)
        {
            Debug.LogWarning("❌ Нет выбранной способности!");
            return;
        }
        Debug.Log($"🗡️ Атака по клетке {targetCell} из позиции {currentAttackOrigin}");
        int damage = Random.Range(selectedSkill.minDamage, selectedSkill.maxDamage + 1);
        DamageObjectAt(targetCell, damage);
        GlobalCore.Instance.PlayerManager.SetSkillOnCooldown(selectedSkill);
        TurnManager.Instance.AdvanceTurn();
        GlobalCore.Instance.PlayerSkillManager.skillCooldowns[selectedSkill] = Mathf.CeilToInt(selectedSkill.cooldown);
        
        GlobalCore.Instance.PlayerSkillManager.UpdateCooldownUI();
        // Здесь ты можешь:
        // - Проверить есть ли объект/NPC
        // - Отнять HP
        // - Проиграть анимацию
        // - Создать эффект
    }
    public void DamageObjectAt(Vector2Int hitPosition, int damage)
    {
        foreach (var biome in GlobalCore.Instance.WorldManager.Bioms)
        {
            foreach (var group in biome.Value.Values)
            {
                foreach (var objEntry in group.Objects)
                {
                    ObjectOnMap obj = objEntry.Value;

                    // ✅ Проверка: входит ли ударенная клетка в список занятых клеток
                    if (obj.occupiedCells != null && obj.occupiedCells.Contains(hitPosition))
                    {
                        obj.CurrectHitBox -= damage;
                        Debug.Log($"Объекту нанесено {damage} урона.");
                        Vector3 worldPos = obj.currObj.transform.position;
                        GlobalCore.Instance.PoolManagerUISuppWindow.ShowFloatingText
                        (
                            worldPos,                // позиция на карте
                            $"-{damage}",               // текст
                            Color.red                   // цвет для урона
                        );

                        if (obj.CurrectHitBox <= 0)
                        {
                            Debug.Log($"💥 Объект {obj.type} разрушен на клетке {hitPosition}");

                            // Удаляем с карты
                            foreach (var cell in obj.occupiedCells)
                                group.Objects.Remove(cell);

                            // Возврат в пул
                            if (obj.currObj != null)
                                PoolManagerSpecial.Instance.ReturnSpecial(obj.currObj);

                            // Генерация дропа
                            var objData = GlobalCore.Instance.ObjectManager.baseObjects[(Objects)obj.type];
                            GenerateDropFromObject(objData, GlobalCore.Instance.PlayerManager.currentGridPos);
                        }
                        else
                        {
                            // Обновляем объект с новым HP
                            group.Objects[obj.position] = obj;
                        }
                        return;
                    }
                }
            }
        }

        Debug.Log("❗ Удар нанесён в клетку, где нет объекта.");
    }
    private void GenerateDropFromObject(ObjectsInfoData objData, Vector2 dropWorldPos)
    {
        int iterations = Random.Range(objData.dropIterationsRange.x, objData.dropIterationsRange.y);

        // Группировка дропа: itemID → количество
        Dictionary<ItemsType, int> dropSummary = new();

        for (int i = 0; i < iterations; i++)
        {
            float roll = Random.value;
            float cumulative = 0f;

            foreach (var entry in objData.dropItems)
            {
                cumulative += entry.chanse;
                if (roll <= cumulative)
                {
                    if (!dropSummary.ContainsKey(entry.itemID))
                        dropSummary[entry.itemID] = 0;

                    dropSummary[entry.itemID] += 1;
                    GlobalCore.Instance.ItemManager.AddItem(entry.itemID, 1);

                    break;
                }
            }
        }

        // Показать UI дропа
        foreach (var kvp in dropSummary)
        {
            ItemsType itemID = kvp.Key;
            int count = kvp.Value;

            string itemName = GlobalCore.Instance.ItemManager.GetItemName(itemID); // ты можешь реализовать этот метод
            string dropText = $"+{count} {itemName}";
            
            GlobalCore.Instance.PoolManagerUISuppWindow.ShowFloatingText(Camera.main.ScreenToWorldPoint(new Vector2(Screen.width / 2, Screen.height / 2)), dropText, Color.yellow);
        }
    }
}
