﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class PlayerManager : MonoBehaviour
{
    public Vector2Int currentGridPos = new(0, 0);
    private Coroutine moveRoutine = null;
    private Queue<Vector2Int> path = new();
    private Vector2Int? currentTargetCell = null;
    private Dictionary<SkillsData, int> skillCooldowns = new();

    [SerializeField] private float baseSpeed = 3f;
    [SerializeField] private float lakeSpeedMultiplier = 0.5f;
    private float moveSpeed;

    private bool isMoving = false;
    private bool inWater = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            TurnManager.Instance.AdvanceTurn();
        }
        if (Input.GetKeyDown(KeyCode.D))
            Debug.Log(GlobalCore.Instance.PlayerSkillManager.skillCooldowns.Keys);
        if (Input.GetMouseButtonDown(1))
        {
            Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mouseWorld2D = new(mouseWorldPos.x, mouseWorldPos.y);

            RaycastHit2D hit = Physics2D.Raycast(mouseWorld2D, Vector2.zero);
            if (hit.collider != null)
            {
                Debug.Log($"Вы нажали на объект {hit.transform.localPosition}");

                Vector2Int cellKey = new
                    (
                        Mathf.FloorToInt(hit.collider.transform.localPosition.x + 0.5f),
                        Mathf.FloorToInt(hit.collider.transform.localPosition.y + 0.5f)
                    );

                if (GlobalCore.Instance.WorldManager.GlobalMap.ContainsKey(cellKey))
                {
                    GenerateStraightPath(currentGridPos, cellKey);
                    if (moveRoutine != null)
                        StopCoroutine(moveRoutine);
                    moveRoutine = StartCoroutine(MoveAlongPath());
                }
            }
        }
    }

    private void GenerateStraightPath(Vector2Int from, Vector2Int to)
    {
        path.Clear();
        GlobalCore.Instance.PoolManagerHighLight.ReturnAllHighlights();
        GlobalCore.Instance.CombatManager.isAwaitingAttackTarget = false;

        Vector2Int current = from;

        while (current != to)
        {
            Vector2Int nextStep = current;

            // Обрабатываем ось X
            if (current.x < to.x) nextStep.x++;
            else if (current.x > to.x) nextStep.x--;

            // Обрабатываем ось Y
            if (current.y < to.y) nextStep.y++;
            else if (current.y > to.y) nextStep.y--;

            // Проверка проходимости
            if (IsBlocked(nextStep))
            {
                Debug.Log($"🚫 Путь заблокирован на клетке {nextStep}");
                break;
            }

            path.Enqueue(nextStep);
            current = nextStep;
            TurnManager.Instance.AdvanceTurn();
        }
    }

    private IEnumerator MoveAlongPath()
    {
        isMoving = true;

        while (path.Count > 0)
        {
            currentTargetCell = path.Dequeue();
            if (IsBlocked(currentTargetCell.Value))
            {
                Debug.Log("🚧 Путь заблокирован");
                break;
            }

            // Телепорт игрока на новую клетку
            transform.localPosition = new Vector3(currentTargetCell.Value.x, currentTargetCell.Value.y, -1f);
            currentGridPos = currentTargetCell.Value;

            AdjustSpeedByBiome();

            GlobalCore.Instance.PoolManager.GenerateGrinGrade();

            yield return new WaitForSeconds(1f / baseSpeed); // пауза между прыжками
        }

        isMoving = false;
        moveRoutine = null;
    }

    private void AdjustSpeedByBiome()
    {
        Vector2Int pos = new(
            Mathf.RoundToInt(transform.localPosition.x),
            Mathf.RoundToInt(transform.localPosition.y)
        );

        if (GlobalCore.Instance.WorldManager.GlobalMap.TryGetValue(pos, out var tile)) //Добавить поиск по типу Биома!
        {
            if (tile.type == BiomsType.Lakes && !inWater)
            {
                baseSpeed = baseSpeed * lakeSpeedMultiplier;
                inWater = true;
            }
            else if (tile.type != BiomsType.Lakes && inWater)
            {
                baseSpeed = baseSpeed / lakeSpeedMultiplier;
                inWater = false;
            }
        }
    }

    private bool IsBlocked(Vector2Int cell)
    {
        // Проверка на NPC
        if (GlobalCore.Instance.NPCManager.NPCPositions.ContainsKey(cell))
            return true;

        // Проверка на объекты
        foreach (var biome in GlobalCore.Instance.WorldManager.Bioms)
        {
            foreach (var group in biome.Value.Values)
            {
                foreach (var obj in group.Objects.Values)
                {
                    if (obj.occupiedCells != null && obj.occupiedCells.Contains(cell))
                    {
                        var objData = GlobalCore.Instance.ObjectManager.baseObjects[(Objects)obj.type];
                        if (objData.movementModifier <= 0.01f)
                            return true;
                    }
                }
            }
        }

        return false;
    }
   

    public void SetSkillOnCooldown(SkillsData skill)
    {
        if (skill.cooldown > 0)
            skillCooldowns[skill] = Mathf.RoundToInt(skill.cooldown);
    }

    public void ReduceCooldowns()
    {
        var keys = skillCooldowns.Keys.ToList();
        foreach (var key in keys)
        {
            skillCooldowns[key]--;
            if (skillCooldowns[key] <= 0)
                skillCooldowns.Remove(key);
        }
    }
}