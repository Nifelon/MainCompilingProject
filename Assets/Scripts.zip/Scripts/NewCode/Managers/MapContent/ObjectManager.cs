﻿using System.Collections.Generic;
using System.Drawing;
using UnityEngine;

public class ObjectManager : MonoBehaviour
{
    public static ObjectManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
        baseObjects = new();
        var allObjects = Resources.LoadAll<ObjectsInfoData>("Objects");
        foreach (var obj in allObjects)
        {
            if (!baseObjects.ContainsKey(obj.typeObject))
                baseObjects.Add(obj.typeObject, obj);
            else
                Debug.LogWarning($"Повторный объект: {obj.typeObject}");
        }
    }
         public Dictionary<Objects, ObjectsInfoData> baseObjects;
    public struct ObjectOnMap
    {
        public int id;
        public int type;
        public Vector2Int position;
        public Vector2Int size;
        public GameObject currObj;
        public List<Vector2Int> occupiedCells;
        public int CurrectHitBox;
        public ObjectOnMap(int id, int type, Vector2Int position, Vector2Int size, GameObject currObj, List<Vector2Int> occupiedCells, int CurrectHitBox)
        {
            this.id = id;
            this.type = type;
            this.position = position;
            this.size = size;
            this.currObj = currObj;
            this.occupiedCells = occupiedCells;
            this.CurrectHitBox = CurrectHitBox;
        }
    }
    public Dictionary<BiomsType, float> ObjectDensity = new Dictionary< BiomsType, float>()
    {
        {BiomsType.Forests,0.6f }
    };
    public void GenerateObjOnMap(BiomsType ID)
    {
        if (!GlobalCore.Instance.WorldManager.Bioms.ContainsKey(ID) || GlobalCore.Instance.WorldManager.Bioms[ID] == null)
        {
            Debug.LogWarning($"Биом {ID} не был сгенерирован");
            return;
        }

        // Получаем данные биома
        BiomeData biomeData = GlobalCore.Instance.BiomeManager.GetBiomeData(ID);
        if (biomeData == null || biomeData.spawnableObjects.Count == 0)
        {
            Debug.LogWarning($"Нет доступных объектов для биома {ID}");
            return;
        }

        for (int i = 1; i <= GlobalCore.Instance.WorldManager.Bioms[ID].Count; i++)
        {
            int createdObjects = 0;
            int attempts = GlobalCore.Instance.WorldManager.Bioms[ID][i].squareBOM.Count;
            int targetAmount = Mathf.FloorToInt(GlobalCore.Instance.WorldManager.Bioms[ID][i].squareBOM.Count * ObjectDensity[ID]);

            while (createdObjects < targetAmount && attempts > 0)
            {
                attempts--;

                // 1. Случайная точка
                int posIndex = Random.Range(0, GlobalCore.Instance.WorldManager.Bioms[ID][i].squareBOM.Count);
                Vector2Int startPos = GlobalCore.Instance.WorldManager.Bioms[ID][i].squareBOM[posIndex];

                // 2. Выбор объекта на основе шансов из BiomeData
                float roll = Random.value;
                float cumulative = 0f;
                Objects selectedObject = Objects.Tree; // значение по умолчанию
                bool found = false;

                foreach (var entry in biomeData.spawnableObjects)
                {
                    cumulative += entry.spawnChance;
                    if (roll <= cumulative)
                    {
                        selectedObject = entry.objectType;
                        found = true;
                        break;
                    }
                }

                if (!found)
                    continue;

                // 3. Получаем данные объекта
                ObjectsInfoData objectInfo = baseObjects[selectedObject];
                Vector2Int objSize = objectInfo.Size;
                if (objSize.x != objSize.y)
                    if (Random.value <= 0.5f)
                        objSize = new(objSize.y, objSize.x); ;

                // 4. Проверка — заняты ли клетки в радиусе вокруг всей зоны объекта
                bool isBlocked = false;

                // Границы зоны с радиусом в 1 клетку
                int minX = startPos.x - 1;
                int maxX = startPos.x + objSize.x;
                int minY = startPos.y - 1;
                int maxY = startPos.y + objSize.y;

                for (int x = minX; x <= maxX; x++)
                {
                    for (int y = minY; y <= maxY; y++)
                    {
                        Vector2Int checkCell = new(x, y);
                        if (GlobalCore.Instance.WorldManager.Bioms[ID][i].Objects.ContainsKey(checkCell))
                        {
                            isBlocked = true;
                            break;
                        }
                    }
                    if (isBlocked) break;
                }

                // 5. Добавляем объект
                if (!isBlocked)
                {
                    List<Vector2Int> occupiedCells = new();
                    for (int x = 0; x < objSize.x; x++)
                    {
                        for (int y = 0; y < objSize.y; y++)
                        {
                            Vector2Int cell = new(startPos.x + x, startPos.y + y);
                            occupiedCells.Add(cell);
                        }
                    }

                    ObjectOnMap newObj = new(i, (int)selectedObject, startPos, objSize, null, occupiedCells, baseObjects[selectedObject].HitBox);
                    GlobalCore.Instance.WorldManager.Bioms[ID][i].Objects.Add(startPos, newObj);
                    createdObjects++;
                }
            }
            Debug.Log($"[{ID} → Группа {i}] Объектов сгенерировано: {createdObjects}");
        }
    }
    public bool TryGetObjectAt(Vector2Int cell, out ObjectOnMap obj)
    {
        foreach (var biome in GlobalCore.Instance.WorldManager.Bioms)
        {
            foreach (var group in biome.Value.Values)
            {
                if (group.Objects.TryGetValue(cell, out obj))
                    return true;
            }
        }

        obj = default;
        return false;
    }
}
