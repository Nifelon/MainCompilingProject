﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

public class NPCManager : MonoBehaviour
{
    public static NPCManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            LoadAllNPC();
            Instance = this;
        }
        else
        {

            Destroy(gameObject);
        }
    }

    public Dictionary<BiomsType, float> NPCDensity = new()
    {
        {BiomsType.Cities,0.05f }
    };
    public Dictionary<Vector2Int, AllyNPC> NPCPositions = new();
    public struct AllyNPC
    {
        public int id;
        public int name;
        public AllyNPCType type;
        public GameObject CurrObj;
        public Vector2 position;
        public Color color;
        public DialogData Dialog;
        //public List<QuestGiver> Quests;
        //public Dictionary<int, Item> Items;
        //public int Gold;
        public AllyNPC(int id, int name, AllyNPCType type, GameObject CurrObj, Vector2 position, Color color, DialogData Dialog/* List<QuestGiver> Quests, Dictionary<int, Item> Items, int Gold*/)
        {
            this.id = id;
            this.name = name;
            this.type = type;
            this.CurrObj = CurrObj;
            this.position = position;
            this.color = color;
            this.Dialog = Dialog;
            //this.Quests = Quests;
            //this.Items = Items;
            //this.Gold = Gold;
        }
    }
    public Dictionary<int, string> NamesNPC = new Dictionary<int, string>()
    {
        {1,"Аппий" },
        {2,"Децим" },
        {3,"Кезон" },
        {4,"Маний" },
        {5,"Сервий" },
        {6,"Гай" },
        {7,"Гней" },
        {8,"Луций" },
        {9,"Тит" },
        {10,"Тиберий" },

    };
    public Dictionary<AllyNPCType, NPCDataBase> NPCDatabase { get; private set; }
    private void LoadAllNPC()
    {
        NPCDatabase = new Dictionary<AllyNPCType, NPCDataBase>();

        var allNPC = Resources.LoadAll<NPCDataBase>("NPCAlly");

        foreach (var NPC in allNPC)
        {
            if (!NPCDatabase.ContainsKey(NPC.npcType))
            {
                NPCDatabase.Add(NPC.npcType, NPC);
            }
            else
            {
                Debug.LogWarning($"❗ Дубликат NPC: {NPC.npcType}");
            }
        }

        Debug.Log($"🧩 Загружено предметов: {NPCDatabase.Count}");
    }

    public void GenerateNPCInCity()
    {
        // Проходим по каждому городу
        foreach (var city in GlobalCore.Instance.WorldManager.Bioms[BiomsType.Cities])
        {
            var cityID = city.Key;
            var cityData = city.Value;

            int createdNPC = 0;
            int maxAttempts = 10000; // Количество попыток
            while (cityData.squareBOM.Count * NPCDensity[BiomsType.Cities] > createdNPC && maxAttempts > 0)
            {
                maxAttempts--;

                // Выбираем случайную клетку
                Vector2Int startPos = cityData.squareBOM[Random.Range(0, cityData.squareBOM.Count)];

                // Проверяем, есть ли NPC рядом
                bool isOccupied = cityData.AllyNPC.Values.Any(npc => Vector2.Distance(npc.position, startPos) < 2);
                if (isOccupied) continue;

                // Генерация данных NPC
                int name = Random.Range(1, NamesNPC.Count + 1);
                int type = Random.Range(1, NPCDatabase.Count + 1);

                // 30% шанс добавить квест NPC
                //if (Random.value < 0.3f)
                //{
                //    int questID = Random.Range(1, 4);
                //    int countForQuest = Global.MainGameObject.Controller.GetComponent<QuestBase>().RewardCountforQuest(questID);
                //    int goldForQuest = Global.MainGameObject.Controller.GetComponent<QuestBase>().RewardGoldforQuest(questID, countForQuest);
                //    int expForQuest = Global.MainGameObject.Controller.GetComponent<QuestBase>().RewardEXPforQuest(questID, countForQuest);
                //    quests.Add(new Global.QuestGiver(questID, countForQuest, goldForQuest, expForQuest));
                //}

                // Добавляем NPC в город
                int npcID = cityData.AllyNPC.Count + 1;
                var InfoNPC = NPCDatabase[(AllyNPCType)type];
                DialogData assignedDialog = ScriptableObject.CreateInstance<DialogData>();
                assignedDialog.options = new List<DialogButtonOption>();

                // Перманентные опции
                assignedDialog.options.Add(new DialogButtonOption { label = "Узнать слухи", action = DialogAction.ExitDialog, condition = DialogButtonType.None });
                

                // Условные опции
                if ((AllyNPCType)type == AllyNPCType.Blacksmith|| (AllyNPCType)type == AllyNPCType.Armorer)
                    assignedDialog.options.Add(new DialogButtonOption { label = "Починить", action = DialogAction.OpenRepairPanel, condition = DialogButtonType.IsBlacksmith });

                if ((AllyNPCType)type == AllyNPCType.Merchant)
                    assignedDialog.options.Add(new DialogButtonOption { label = "Торговать", action = DialogAction.ShowRumors, condition = DialogButtonType.IsMerchant });

                // В будущем — проверка на квесты
                //if (Random.value < 0.3f)
                //    assignedDialog.options.Add(new DialogButtonOption { label = "Задание", action = DialogAction.Quest, condition = DialogButtonType.HasQuest });
                assignedDialog.options.Add(new DialogButtonOption { label = "Уйти", action = DialogAction.ExitDialog, condition = DialogButtonType.None });
                cityData.AllyNPC[npcID] = new AllyNPC(npcID, name, (AllyNPCType)type, null, startPos, InfoNPC.outfitColor,assignedDialog);
                NPCPositions[startPos] = cityData.AllyNPC[npcID];
                createdNPC++;
            }
        }
        if (GlobalCore.Instance.WorldManager.Bioms[BiomsType.Cities].Count != 0)
            Debug.Log($"Сгенерировано НПС{GlobalCore.Instance.WorldManager.Bioms[BiomsType.Cities][1].AllyNPC.Count}");
    }
    public bool TryGetNPCAt(Vector2Int cell, out AllyNPC npc)
    {
        foreach (var biome in GlobalCore.Instance.WorldManager.Bioms)
        {
            foreach (var group in biome.Value.Values)
            {
                foreach (var pair in group.AllyNPC)
                {
                    if (new Vector2Int((int)pair.Value.position.x, (int)pair.Value.position.y) == cell)

                    {
                        npc = pair.Value;
                        return true;
                    }
                }
            }
        }

        npc = default;
        return false;
    }
}
