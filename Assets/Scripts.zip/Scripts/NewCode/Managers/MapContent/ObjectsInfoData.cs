using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.Progress;

[CreateAssetMenu(fileName = "ObjectsInfoData", menuName = "Data/ObjectsData")]
public class ObjectsInfoData : ScriptableObject
{
    public Objects typeObject;
    public string NameObject;
    public Vector2Int Size;
    public Sprite sprite;
    //public Color Colorobject;
    [Range(0, 1f)]
    public float movementModifier;
    public bool avoidOtherObjects;
    public int HitBox;
    public bool HighObject;
    public bool isInteractive;
    public InteractionType interactionType = InteractionType.None;
    [Header("���� ���������")]
    public Vector2Int dropIterationsRange = new(3, 5); // min � max ��������
    public List<DropItemData> dropItems;
    [System.Serializable]
    public class DropItemData
    {
        public ItemsType itemID;
        [Range(0f, 1f)]
        public float chanse;

    }
}
