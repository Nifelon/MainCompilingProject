﻿using NUnit.Framework.Interfaces;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{
    public static ItemManager Instance { get; private set; }
    public Dictionary<ItemsType, ItemsData> ItemsDatabase { get; private set; }
    public struct InventoryItem
    {
        public ItemsType itemType;
        public int count;

        public InventoryItem(ItemsType itemType, int count)
        {
            this.itemType = itemType;
            this.count = count;
        }
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            LoadAllItems();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void LoadAllItems()
    {
        ItemsDatabase = new Dictionary<ItemsType, ItemsData>();

        var allItems = Resources.LoadAll<ItemsData>("Items");

        foreach (var item in allItems)
        {
            if (!ItemsDatabase.ContainsKey(item.ItemType))
            {
                ItemsDatabase.Add(item.ItemType, item);
            }
            else
            {
                Debug.LogWarning($"❗ Дубликат предмета: {item.ItemType}");
            }
        }

        Debug.Log($"🧩 Загружено предметов: {ItemsDatabase.Count}");
    }

    public ItemsData GetItemData(ItemsType type)
    {
        if (ItemsDatabase.TryGetValue(type, out var data))
            return data;
        return null;
    }
    public void AddItem(ItemsType itemType, int amount)
    {
        var Info = ItemsDatabase[itemType];
        for (int i = 0; i < GlobalCore.Instance.UIManagerInventory.playerInventory.Count; i++)
        {
            if(GlobalCore.Instance.UIManagerInventory.playerInventory[i].itemType == ItemsType.None)
            {
                GlobalCore.Instance.UIManagerInventory.playerInventory[i] = new(itemType, amount);
                GlobalCore.Instance.UIManagerInventory.UpdateInventoryUI(i);
                return;
            }
            if (GlobalCore.Instance.UIManagerInventory.playerInventory[i].itemType == itemType)
            {
                if(Info.Maxstack >= GlobalCore.Instance.UIManagerInventory.playerInventory[i].count + amount)
                {
                    GlobalCore.Instance.UIManagerInventory.playerInventory[i] = new(itemType, GlobalCore.Instance.UIManagerInventory.playerInventory[i].count + amount);
                    GlobalCore.Instance.UIManagerInventory.UpdateInventoryUI(i);
                    return;
                }
                else
                {
                    amount = (GlobalCore.Instance.UIManagerInventory.playerInventory[i].count + amount) - Info.Maxstack;
                    GlobalCore.Instance.UIManagerInventory.playerInventory[i] = new(itemType, Info.Maxstack);
                    GlobalCore.Instance.UIManagerInventory.UpdateInventoryUI(i);
                    continue;
                }
                
            }
        }
    }
    public string GetItemName(ItemsType itemID)
    {
        if (ItemsDatabase.TryGetValue(itemID, out var data))
            return data.Name;

        return "???";
    }
}
