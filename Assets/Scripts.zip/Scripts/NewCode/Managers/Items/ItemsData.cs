using UnityEngine;

[CreateAssetMenu(fileName = "ItemsData", menuName = "Data/ItemsData")]
public class ItemsData : ScriptableObject
{
    public ItemsType ItemType;
    public string Name;
    [TextArea] public string Info;
    public int Maxstack;
    public float weight;
    public Sprite Icon;
}
