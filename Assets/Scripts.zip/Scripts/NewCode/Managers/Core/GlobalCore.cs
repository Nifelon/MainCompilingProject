﻿using UnityEngine;

public class GlobalCore : MonoBehaviour
{
    public static GlobalCore Instance { get; private set; }

    [Header("UnSorting")]

    private DialogManager _dialogManager;
    private PlayerSkillManager _skillManager;
    private GameManager _gameManager;
    private InteractionManager _interactionManager;
    private ActionManager _actionManager;
    private CombatManager _combatManager;
    private ItemManager _itemManager;
    private TurnManager _turnManager;

    [Header("Pooling")]

    private PoolManager _poolManager;
    private PoolManagerMainTile _poolManagerMainTile;
    private PoolManagerSpecial _poolManagerSpecial;
    private PoolManagerHighLight _poolManagerHighLight;
    private PoolManagerUISuppWindow _poolManagerUISuppWindow;

    [Header("UIManager")]

    private UIManagerSkillPanel _skillPanel;
    private UIManager _uiManager;
    private UIManagerConMenu _uiConMenu;
    private UIManagerDialogPanel _dialogPanel;
    private UIManagerInventory _managerInventory;
    private UIManagerQuestPanel _questPanel;
    private UIManagerGlobalMap _globalMap;
    private ContextOption _contextOption;

    [Header("MainMapManager")]

    private MainGameObjects _mainGameObjects;
    private WorldManager _worldManager;
    private ObjectManager _objectManager;
    private NPCManager _npcManager;
    private PlayerManager _playerManager;
    private BiomeManager _biomeManager;

    [Header("UnSortingInitializate")]

    public DialogManager DialogManager
    {
        get
        {
            if(_dialogManager == null) 
                _dialogManager=FindAnyObjectByType<DialogManager>();
            return _dialogManager;
        }
    }
    public PlayerSkillManager PlayerSkillManager
    {
        get
        {
            if (_skillManager == null)
                _skillManager = FindAnyObjectByType<PlayerSkillManager>();
            return _skillManager;
        }
    }
    public TurnManager TurnManager
    {
        get
        {
            if (_turnManager == null)
                _turnManager = FindAnyObjectByType<TurnManager>();
            return _turnManager;
        }
    }
    public GameManager GameManager
    {
        get
        {
            if (_gameManager == null)
                _gameManager = FindAnyObjectByType<GameManager>();
            return _gameManager;
        }
    }
    public InteractionManager InteractionManager
    {
        get
        {
            if (_interactionManager == null)
                _interactionManager = FindAnyObjectByType<InteractionManager>();
            return _interactionManager;
        }
    }
    public ActionManager ActionManager
    {
        get
        {
            if (_actionManager == null)
                _actionManager = FindAnyObjectByType<ActionManager>();
            return _actionManager;
        }
    }
    public CombatManager CombatManager
    {
        get
        {
            if (_combatManager == null)
                _combatManager = FindAnyObjectByType<CombatManager>();
            return _combatManager;
        }
    }
    public ItemManager ItemManager
    {
        get
        {
            if (_itemManager == null)
                _itemManager = FindAnyObjectByType<ItemManager>();
            return _itemManager;
        }
    }

    [Header("PoolingInitializate")]

    public PoolManager PoolManager
    {
        get
        {
            if (_poolManager == null)
                _poolManager = FindAnyObjectByType<PoolManager>();
            return _poolManager;
        }
    }
    public PoolManagerMainTile PoolManagerMainTile
    {
        get
        {
            if (_poolManagerMainTile == null)
                _poolManagerMainTile = FindAnyObjectByType<PoolManagerMainTile>();
            return _poolManagerMainTile;
        }
    }
    public PoolManagerSpecial PoolManagerSpecial
    {
        get
        {
            if (_poolManagerSpecial == null)
                _poolManagerSpecial = FindAnyObjectByType<PoolManagerSpecial>();
            return _poolManagerSpecial;
        }
    }
    public PoolManagerHighLight PoolManagerHighLight
    {
        get
        {
            if (_poolManagerHighLight == null)
                _poolManagerHighLight = FindAnyObjectByType<PoolManagerHighLight>();
            return _poolManagerHighLight;
        }
    }
    public PoolManagerUISuppWindow PoolManagerUISuppWindow
    {
        get
        {
            if (_poolManagerUISuppWindow == null)
                _poolManagerUISuppWindow = FindAnyObjectByType<PoolManagerUISuppWindow>();
            return _poolManagerUISuppWindow;
        }
    }

    [Header("UIManagerInitializate")]

    public UIManagerSkillPanel UIManagerSkillPanel
    {
        get
        {
            if (_skillPanel == null)
                _skillPanel = FindAnyObjectByType<UIManagerSkillPanel>();
            return _skillPanel;
        }
    }
    public UIManager UIManager
    {
        get
        {
            if (_uiManager == null)
                _uiManager = FindAnyObjectByType<UIManager>();
            return _uiManager;
        }
    }
    public UIManagerConMenu UIManagerConMenu
    {
        get
        {
            if (_uiConMenu == null)
                _uiConMenu = FindAnyObjectByType<UIManagerConMenu>();
            return _uiConMenu;
        }
    }
    public UIManagerDialogPanel UIManagerDialogPanel
    {
        get
        {
            if (_dialogPanel == null)
                _dialogPanel = FindAnyObjectByType<UIManagerDialogPanel>();
            return _dialogPanel;
        }
    }
    public UIManagerInventory UIManagerInventory
    {
        get
        {
            if (_managerInventory == null)
                _managerInventory = FindAnyObjectByType<UIManagerInventory>();
            return _managerInventory;
        }
    }
    public UIManagerQuestPanel UIManagerQuestPanel
    {
        get
        {
            if (_questPanel == null)
                _questPanel = FindAnyObjectByType<UIManagerQuestPanel>();
            return _questPanel;
        }
    }
    public UIManagerGlobalMap UIManagerGlobalMap
    {
        get
        {
            if (_globalMap == null)
                _globalMap = FindAnyObjectByType<UIManagerGlobalMap>();
            return _globalMap;
        }
    }
    public ContextOption ContextOption
    {
        get
        {
            if (_contextOption == null)
                _contextOption = FindAnyObjectByType<ContextOption>();
            return _contextOption;
        }
    }


    [Header("MainMapManagersInitializate")]

    public MainGameObjects MainGameObjects
    {
        get
        {
            if (_mainGameObjects == null)
                _mainGameObjects = FindAnyObjectByType<MainGameObjects>();
            return _mainGameObjects;
        }
    }
    public WorldManager WorldManager
    {
        get
        {
            if (_worldManager == null)
                _worldManager = FindAnyObjectByType<WorldManager>();
            return _worldManager;
        }
    }
    public ObjectManager ObjectManager
    {
        get
        {
            if (_objectManager == null)
                _objectManager = FindAnyObjectByType<ObjectManager>();
            return _objectManager;
        }
    }
    public NPCManager NPCManager
    {
        get
        {
            if (_npcManager == null)
                _npcManager = FindAnyObjectByType<NPCManager>();
            return _npcManager;
        }
    }
    public PlayerManager PlayerManager
    {
        get
        {
            if (_playerManager == null)
                _playerManager = FindAnyObjectByType<PlayerManager>();
            return _playerManager;
        }
    }
    public BiomeManager BiomeManager
    {
        get
        {
            if (_biomeManager == null)
                _biomeManager = FindAnyObjectByType<BiomeManager>();
            return _biomeManager;
        }
    }



    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            // Сохраняем между сценами
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        Debug.Log("GlobalCore загружен.");
        if (BiomeManager == null)
        {
            _biomeManager = Resources.Load<BiomeManager>("Biomes/BiomeManager");
            if (BiomeManager == null)
            {
                Debug.LogError("❌ BiomeManager не найден в Resources/Biomes!");
            }
            else
            {
                Debug.Log("✅ BiomeManager загружен из Resources.");
            }
        }
    }
}