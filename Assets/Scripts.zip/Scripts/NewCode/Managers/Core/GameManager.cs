using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public enum GameState { Loading, Playing, Paused, GameOver }
    public GameState CurrentState { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        ChangeState(GameState.Loading);
        StartCoroutine(StartGameAfterLoad());
    }
    public void Update()
    {
        if(Input.GetKeyUp(KeyCode.G))
        {
            Debug.Log("�������� �����...");
            GlobalCore.Instance.PoolManager.ReturnAllPoolingElements();
            Debug.Log("��������� �����...");
            GlobalCore.Instance.WorldManager.GenerationNewGameMap();
            Debug.Log("��������� ��������...");
            GlobalCore.Instance.ObjectManager.GenerateObjOnMap(BiomsType.Forests);
            Debug.Log("��������� ���...");
            GlobalCore.Instance.NPCManager.GenerateNPCInCity();
            Debug.Log("���������� �����...");
            GlobalCore.Instance.PoolManagerMainTile.GenerateSquarePool();
            GlobalCore.Instance.PoolManagerSpecial.GenerateSpecialPool();
            GlobalCore.Instance.PoolManager.GenerateGrinGrade();
        }
    }
    private IEnumerator StartGameAfterLoad()
    {
        yield return new WaitForSeconds(1f); // �������� �������� (����� ������)
        StartGame();
    }

    public void ChangeState(GameState newState)
    {
        CurrentState = newState;
        Debug.Log($"Game State changed to: {newState}");

        switch (newState)
        {
            case GameState.Playing:
                Time.timeScale = 1;
                break;
            case GameState.Paused:
                Time.timeScale = 0;
                break;
            case GameState.GameOver:
                break;
        }
    }

    public void StartGame() => ChangeState(GameState.Playing);
    public void PauseGame() { if (CurrentState == GameState.Playing) ChangeState(GameState.Paused); }
    public void ResumeGame() { if (CurrentState == GameState.Paused) ChangeState(GameState.Playing); }
    public void EndGame() => ChangeState(GameState.GameOver);
}

