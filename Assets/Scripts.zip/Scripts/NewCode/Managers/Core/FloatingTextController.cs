﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class FloatingTextController : MonoBehaviour
{
    public Text text;
    private RectTransform rt;
    private CanvasGroup cg;

    private void Awake()
    {
        rt = GetComponent<RectTransform>();
        cg = GetComponent<CanvasGroup>();
    }

    public void Setup(string value, Color color)
    {
        text.text = value;
        text.color = color;

        //rt.anchoredPosition = Vector2.zero;
        cg.alpha = 1f;

        StartCoroutine(FloatUp());
    }

    private IEnumerator FloatUp()
    {
        Vector2 start = rt.anchoredPosition;
        Vector2 end = start + new Vector2(0, 50f);

        float duration = 1f;
        float time = 0f;

        while (time < duration)
        {
            time += Time.deltaTime;
            float t = time / duration;

            rt.anchoredPosition = Vector2.Lerp(start, end, t);
            cg.alpha = 1f - t;

            yield return null;
        }

        GlobalCore.Instance.PoolManagerUISuppWindow.ReturnFloatingText(gameObject);
    }
}

