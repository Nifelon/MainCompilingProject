﻿using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class TurnManager : MonoBehaviour
{
    public static TurnManager Instance { get; private set; }
    public int CurrentTurn { get; private set; } = 0;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    /// <summary>
    /// Переход к следующему ходу
    /// </summary>
    public void AdvanceTurn()
    {
        CurrentTurn++;
        Debug.Log($"▶️ Ход {CurrentTurn}");
        GlobalCore.Instance.UIManagerGlobalMap.CreateGlobalMap();
        // Пример: обновляем кулдауны у игрока
        DecreaseCooldowns();

        // В будущем: добавить логику обновления NPC и окружения
    }
    public void DecreaseCooldowns()
    {
        var keys = GlobalCore.Instance.PlayerSkillManager.skillCooldowns.Keys.ToList();
        foreach (var skill in keys)
        {
            GlobalCore.Instance.PlayerSkillManager.skillCooldowns[skill]--;
            if (GlobalCore.Instance.PlayerSkillManager.skillCooldowns[skill] <= 0)
                GlobalCore.Instance.PlayerSkillManager.skillCooldowns.Remove(skill);
        }

        GlobalCore.Instance.PlayerSkillManager.UpdateCooldownUI();
    }
}
