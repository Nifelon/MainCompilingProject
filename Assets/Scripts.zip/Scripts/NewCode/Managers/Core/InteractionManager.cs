using UnityEngine;

public class InteractionManager : MonoBehaviour
{
    public static InteractionManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {

            Destroy(gameObject);
        }
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mouseWorld2D = new(mouseWorldPos.x, mouseWorldPos.y);

            RaycastHit2D hit = Physics2D.Raycast(mouseWorld2D, Vector2.zero);
            if (hit.collider != null)
            {
                Vector2Int clickedCell = new(
                    Mathf.RoundToInt(hit.collider.transform.localPosition.x),
                    Mathf.RoundToInt(hit.collider.transform.localPosition.y)
                );

                Vector2Int playerPos = GlobalCore.Instance.PlayerManager.currentGridPos;
                if (Vector2Int.Distance(playerPos, clickedCell) > 1f)
                    return;

                // ��������: ���� �� ������ � ���� ������
                if (GlobalCore.Instance.ObjectManager.TryGetObjectAt(clickedCell, out var obj))
                {
                    var so = GlobalCore.Instance.ObjectManager.baseObjects[(Objects)obj.type];
                    if (so.isInteractive)
                        InteractionManager.Instance.PerformAction(so.interactionType, clickedCell);
                }

                // ��������: ���� �� NPC � ���� ������
                if (GlobalCore.Instance.NPCManager.TryGetNPCAt(clickedCell, out var npc))
                {
                    var so = GlobalCore.Instance.NPCManager.NPCDatabase[npc.type];
                    if (so.isInteractive)
                    {
                        InteractionManager.Instance.PerformAction(so.interactionType, clickedCell);
                        Debug.Log(so.npcType);
                    }
                }
            }
        }
    }
    public void PerformAction(InteractionType type, Vector2Int position)
    {
        switch (type)
        {
            case InteractionType.GatherBush:
                Debug.Log("����� �������");
                int x =Random.Range(1, 11);
                GlobalCore.Instance.ItemManager.AddItem(ItemsType.Berry, x);
                //BushManager.Instance.Gather(position);
                break;

            case InteractionType.OpenCraft:
                //CraftingUI.Instance.Open();
                break;

            case InteractionType.TalkToNPC:
                Debug.Log("�� ����������");
                GlobalCore.Instance.UIManager.ToggleUI(UIManagerDialogPanel.DialogPanel);
                break;

            default:
                Debug.Log("��� �������� ��� ����� ���� ��������������.");
                break;
        }
    }
}
