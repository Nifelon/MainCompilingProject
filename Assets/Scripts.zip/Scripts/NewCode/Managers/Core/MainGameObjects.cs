using UnityEngine;

public class MainGameObjects : MonoBehaviour
{
    public static MainGameObjects Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public GameObject Player { get; private set; }
    public GameObject MainTile { get; private set; }
    public GameObject HighLightTile { get; private set; }
    public GameObject MainSpecial { get; private set; }
    public GameObject Canvas { get; private set; }
    public GameObject WorldRoot { get; private set; }

    public GameObject UISuppWindow { get; private set; }

    public void GenerateMainGameObjects()
    {
        Canvas = GameObject.FindWithTag("Canvas");
        WorldRoot = GameObject.FindWithTag("WorldRoot");
        Player = WorldRoot.transform.Find("Player").gameObject;
        MainTile = WorldRoot.transform.Find("MainTile").gameObject;
        MainSpecial = WorldRoot.transform.Find("SpecialTile").gameObject;
        HighLightTile = WorldRoot.transform.Find("HighLightTile").gameObject;
        UISuppWindow = Canvas.transform.Find("UISupp").gameObject;
        var renderer = Player.GetComponent<SpriteRenderer>();
        if (renderer != null)
        {
            renderer.sortingLayerName = "Player";
            renderer.sortingOrder = -(int)Player.transform.localPosition.y; // �������
        }
    }    
}
