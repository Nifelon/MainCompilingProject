﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms;

public class PoolManager : MonoBehaviour
{
    [SerializeField] private BiomeManager biomeManager;
    public static PoolManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    int RadiusPooling = 15;
    
    public void GenerateGrinGrade()
    {
        Vector2Int playerpos = GetSquareCoords(GlobalCore.Instance.MainGameObjects.Player.transform.localPosition);
        for (int x = -RadiusPooling; x <= RadiusPooling; x++)
            for (int y = -RadiusPooling; y <= RadiusPooling; y++)
            {
                Vector2Int squarePos = playerpos + new Vector2Int(x, y);


                if (!GlobalCore.Instance.PoolManagerMainTile.activeSquares.ContainsKey(squarePos))
                {
                    Vector3 worldPos = SquareToWorldPosition(squarePos);
                    GameObject square = GlobalCore.Instance.PoolManagerMainTile.GetSquare(worldPos, squarePos);
                    if (square != null)
                        GlobalCore.Instance.PoolManagerMainTile.activeSquares[squarePos] = square;
                }
                if (!GlobalCore.Instance.PoolManagerSpecial.activeSpecial.ContainsKey(squarePos))
                {
                    Vector3 worldPos = SquareToWorldPosition(squarePos);
                    GameObject special = GlobalCore.Instance.PoolManagerSpecial.GetSpecial(worldPos, squarePos);
                    if (special != null)
                        GlobalCore.Instance.PoolManagerSpecial.activeSpecial[squarePos] = special;
                }
            }
        List<Vector2Int> squaresToRemove = new List<Vector2Int>();
        List<Vector2Int> specialToRemove = new List<Vector2Int>();
        foreach (var square in GlobalCore.Instance.PoolManagerMainTile.activeSquares)
        {
            if (Vector3.Distance(GlobalCore.Instance.MainGameObjects.Player.transform.localPosition, square.Value.transform.localPosition) > RadiusPooling * 1.5f)
            {
                GlobalCore.Instance.PoolManagerMainTile.ReturnSquare(square.Value);
                squaresToRemove.Add(square.Key);
            }
        }
        foreach (var special in GlobalCore.Instance.PoolManagerSpecial.activeSpecial)
        {
            if (Vector3.Distance(GlobalCore.Instance.MainGameObjects.Player.transform.localPosition, special.Value.transform.localPosition) > RadiusPooling * 1.5f)
            {
                GlobalCore.Instance.PoolManagerSpecial.ReturnSpecial(special.Value);
                specialToRemove.Add(special.Key);
            }
        }

        foreach (var squareKey in squaresToRemove)
        {
            GlobalCore.Instance.PoolManagerMainTile.activeSquares.Remove(squareKey);
        }
        foreach (var specialKey in specialToRemove)
        {
            GlobalCore.Instance.PoolManagerSpecial.activeSpecial.Remove(specialKey);
        }
        Debug.Log($"Активных клеток после чистки:{GlobalCore.Instance.PoolManagerMainTile.activeSquares.Count}");
        Debug.Log($"Активных объектов после чистки:{GlobalCore.Instance.PoolManagerSpecial.activeSpecial.Count}");
    }
    
    

    //МЕТОДЫ//
    public void ReturnAllPoolingElements()
    {
        List<Vector2Int> squaresToRemove = new List<Vector2Int>();
        List<Vector2Int> specialToRemove = new List<Vector2Int>();
        foreach (var square in GlobalCore.Instance.PoolManagerMainTile.activeSquares)
        {
            GlobalCore.Instance.PoolManagerMainTile.ReturnSquare(square.Value);
            squaresToRemove.Add(square.Key);
        }
        foreach (var special in GlobalCore.Instance.PoolManagerSpecial.activeSpecial)
        {
             GlobalCore.Instance.PoolManagerSpecial.ReturnSpecial(special.Value);
            specialToRemove.Add(special.Key);
        }
        foreach (var squareKey in squaresToRemove)
        {
            GlobalCore.Instance.PoolManagerMainTile.activeSquares.Remove(squareKey);
        }
        foreach (var specialKey in specialToRemove)
        {
            GlobalCore.Instance.PoolManagerSpecial.activeSpecial.Remove(specialKey);
        }
        Debug.Log($"Активных клеток после чистки:{GlobalCore.Instance.PoolManagerMainTile.activeSquares.Count}");
        Debug.Log($"Активных объектов после чистки:{GlobalCore.Instance.PoolManagerSpecial.activeSpecial.Count}");
    }
    public void PaintCell(GameObject square, BiomsType type)
    {
        if (GlobalCore.Instance == null)
        {
            Debug.LogError("❌ GlobalCore.Instance == null!");
            return;
        }
        if (GlobalCore.Instance.BiomeManager == null)
        {
            Debug.LogError("❌ GlobalCore.Instance.BiomeManager == null!");
            return;
        }
        var color = GlobalCore.Instance.BiomeManager.GetBiomeSprite(type);
        square.GetComponent<SpriteRenderer>().sprite = color;
    }

    private Vector2Int GetSquareCoords(Vector3 worldPosition)
    {
        float squareSize = 1.0f;

        int x = Mathf.RoundToInt(worldPosition.x / squareSize);
        int y = Mathf.RoundToInt(worldPosition.y / squareSize);

        return new Vector2Int(x, y);
    }
    private Vector3 SquareToWorldPosition(Vector2Int squareCoords)
    {
        float squareSize = 1.0f;

        float xOffset = squareSize * squareCoords.x;
        float yOffset = squareSize * squareCoords.y;

        return new Vector3(xOffset, yOffset, 0);

    }
}