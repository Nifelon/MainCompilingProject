using UnityEngine;

public enum ClimateZoneType:byte
{
    none,
    ColdZone,
    MediumZone,
    HotZone
}
