using UnityEngine;

public enum BiomsType
{
    None = 0,
    Lakes = 1,
    Rivers = 2,
    Forests = 3,
    Fields = 4,
    Bogs = 5,
    Cities = 6,
    Roads = 7
};
