using UnityEngine;

public enum DialogButtonType
{
    None,
    HasQuest,
    IsMerchant,
    IsBlacksmith
}