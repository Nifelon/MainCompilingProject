using UnityEngine;

public enum SkillType
{
    Melee,
    Range,
    Buff,
    Heal,
    Dash,
    Debuff,
    Summon
}