using UnityEngine;

public enum ItemsType
{
    None,
    Wood,
    Berry,
    Fish,
    Stone,
    Cuprum
}
