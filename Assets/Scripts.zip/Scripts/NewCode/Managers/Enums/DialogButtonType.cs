using UnityEngine;

public enum DialogAction
{
    ShowRumors,
    OpenRepairPanel,
    ShowQuestInfo,
    ExitDialog
}

