using UnityEngine;

public enum ObjectType
{
    TreeSmall,
    TreeBig,
    Bush,
    Rock,
    Boulder,
    NPC
}
