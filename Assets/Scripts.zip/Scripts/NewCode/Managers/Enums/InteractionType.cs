using UnityEngine;

public enum InteractionType
{
    None,
    GatherBush,
    OpenCraft,
    TalkToNPC,
    OpenDialogWindow,
    Trade,
    Repair,
}
