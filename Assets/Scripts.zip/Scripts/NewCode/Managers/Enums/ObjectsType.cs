using UnityEngine;

public enum Objects
{
    Tree = 1,
    LargeTree = 2,
    FallTree = 3,
    Stone = 4,
    LargeStone = 5,
    Bush = 6

}
