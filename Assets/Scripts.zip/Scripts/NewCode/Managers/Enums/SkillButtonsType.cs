using UnityEngine;

public enum SkillButtonType
{
    skill_1 = 1,
    skill_2 = 2, 
    skill_3 = 3, 
    skill_4 = 4, 
    skill_5 = 5, 
    skill_6 = 6, 
    skill_7 = 7, 
    skill_8 = 8, 
    skill_9 = 9, 
    skill_10 = 0
}