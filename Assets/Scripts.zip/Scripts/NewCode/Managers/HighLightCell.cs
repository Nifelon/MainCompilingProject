using UnityEngine;

public class HighlightCell : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;
    private Color baseColor = new Color(1f, 0f, 0f, 0.4f);     // ������� ���������
    private Color hoverColor = new Color(0.5f, 0f, 0f, 0.6f);   // ��� ���������

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        spriteRenderer.color = baseColor;
    }

    void OnMouseEnter()
    {
        Debug.Log("Good");
        spriteRenderer.color = hoverColor;
    }

    void OnMouseExit()
    {
        Debug.Log("Bad");
        spriteRenderer.color = baseColor;
    }
}