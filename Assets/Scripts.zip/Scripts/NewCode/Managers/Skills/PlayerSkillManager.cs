﻿using System.Collections.Generic;
using UnityEngine;

public class PlayerSkillManager : MonoBehaviour
{
    public static readonly KeyCode[] defaultKeys = new KeyCode[10]
{
    KeyCode.Alpha1, KeyCode.Alpha2, KeyCode.Alpha3, KeyCode.Alpha4, KeyCode.Alpha5,
    KeyCode.Alpha6, KeyCode.Alpha7, KeyCode.Alpha8, KeyCode.Alpha9, KeyCode.Alpha0
};
    public static PlayerSkillManager Instance { get; private set; }
    public List<SkillsData> AllSkills { get; private set; }
    public List<SkillsData> activeSkills = new();
    public Dictionary<SkillsData, int> skillCooldowns = new();

    private void Awake()
    {
        if (Instance == null)
        {
            LoadAllSkills(); 
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void LoadAllSkills()
    {
        AllSkills = new List<SkillsData>(Resources.LoadAll<SkillsData>("Skills"));
        activeSkills = AllSkills; //Исправить, во время работы с Скиллами!!!
        Debug.Log($"Загружено способностей {AllSkills.Count}");
    }
    public void UseSkill(int index)
    {
        if (index < 0 || index >= activeSkills.Count)
        {
            Debug.LogWarning("❌ Слот вне диапазона активных способностей.");
            return;
        }

        SkillsData skill = AllSkills[index];

        // ✅ Проверка кулдауна
        if (skillCooldowns.ContainsKey(skill) && skillCooldowns[skill] > 0)
        {
            Debug.Log($"⏳ Способность '{skill.skillName}' на кулдауне! Осталось {skillCooldowns[skill]} ходов.");
            return;
        }

        switch (skill.type)
        {
            case SkillType.Melee:
                CombatManager.Instance.PrepareAttack(
                    GlobalCore.Instance.PlayerManager.currentGridPos,
                    skill
                );
                break;

            //case SkillType.Buff:
            //    ApplyBuffToSelf(skill);
            //    break;

            default:
                Debug.Log($"⚠️ Способность '{skill.skillName}' ещё не реализована.");
                break;
        }
    }
    public void UpdateCooldownUI()
    {
        for (int i = 0; i < 10; i++)
        {
            if (GlobalCore.Instance.UIManagerSkillPanel.CellsSkill.ContainsKey(i) && GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].skillData != null)
            {
                SkillsData skill = GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].skillData;

                if (PlayerSkillManager.Instance.IsSkillOnCooldown(skill, out int turns))
                {
                    GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].CooldownSprite.gameObject.SetActive(true);
                    GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].CoolDownTime.gameObject.SetActive(true);
                    GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].CoolDownTime.text = turns.ToString();
                }
                else
                {
                    GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].CooldownSprite.gameObject.SetActive(false);
                    GlobalCore.Instance.UIManagerSkillPanel.CellsSkill[i].CoolDownTime.gameObject.SetActive(false);
                }
            }
        }
    }
    public bool IsSkillOnCooldown(SkillsData skill, out int turns)
    {
        if (skillCooldowns.TryGetValue(skill, out turns))
            return true;

        turns = 0;
        return false;
    }

}
