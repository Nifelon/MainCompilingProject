﻿using System;
using Game.Items;
using Game.Actors; // ActorIdKind, NPCEnums, CreatureEnums

public static class QuestEventBus
{
    // ==== Типизированные события ====

    /// <summary>Собрано/получено предметов (ItemId, количество).</summary>
    public static event Action<ItemId, int> OnCollect;

    /// <summary>Килл-событие: кто убит.</summary>
    public static event Action<ActorIdKind, NPCEnums, CreatureEnums> OnUnitKilled;

    // ==== Legacy для плавной миграции (можно выпилить позже) ====
    public static event Action<string, int> OnCollectLegacy;
    public static event Action<string> OnUnitKilledLegacy;

    // ==== Raise (типизированные) ====

    public static void RaiseCollect(ItemId itemId, int amount)
    {
        if (amount <= 0) return;
        if (!ItemMap.IsValid(itemId)) return;
        OnCollect?.Invoke(itemId, amount);
    }

    /// <summary>Мост из GUID → ItemId (удобно для сейвов/дроп-таблиц).</summary>
    public static void RaiseCollectGuid(string guid, int amount)
    {
        if (amount <= 0 || string.IsNullOrWhiteSpace(guid)) return;
        if (ItemMap.TryEnumByGuid(guid, out var id))
            OnCollect?.Invoke(id, amount);
        else
            OnCollectLegacy?.Invoke(guid, amount);
    }

    public static void RaiseUnitKilled(ActorIdKind kind, NPCEnums npc, CreatureEnums creature)
    {
        OnUnitKilled?.Invoke(kind, npc, creature);
    }

    // ==== Raise (legacy) ====

    public static void RaiseCollect(string itemId, int amount)
    {
        if (amount <= 0 || string.IsNullOrWhiteSpace(itemId)) return;
        OnCollectLegacy?.Invoke(itemId, amount);
    }

    public static void RaiseUnitKilled(string unitKind)
    {
        if (string.IsNullOrWhiteSpace(unitKind)) return;
        OnUnitKilledLegacy?.Invoke(unitKind);
    }

    [Obsolete("Craft больше не используется: предметные квесты считаются по Collect/инвентарю.")]
    public static void RaiseCraft(string itemId, int amount) { /* no-op */ }
}
