using UnityEngine;

public class UIManagerConMenu : MonoBehaviour
{
    public static UIManagerConMenu Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public static GameObject ScrollViewMainMap;
    public static GameObject MainButton;
    public void InitializateOthers()
    {
        MainButton = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "GamePres/Button");
        ScrollViewMainMap = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "GamePres/ScrollView");
    }



                                                      //������//

    void ClearButton(GameObject List)
    {
        foreach (Transform child in List.transform)
        {
            Destroy(child.gameObject);
        }
    }
}
