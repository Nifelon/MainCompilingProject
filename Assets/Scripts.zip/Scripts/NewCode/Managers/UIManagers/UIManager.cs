using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SocialPlatforms;

public class UIManager : MonoBehaviour
{
    public static bool activeWindow = false;
    
    public static UIManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            ToggleUI(UIManagerGlobalMap.GlobalMap);
            GlobalCore.Instance.UIManagerGlobalMap.CreateGlobalMap();
        }

        if (Input.GetKeyDown(KeyCode.Q))
        {
            ToggleUI(UIManagerQuestPanel.QuestPanel);
        }

        if (Input.GetKeyDown(KeyCode.I))
        {
            ToggleUI(UIManagerInventory.Inventory);
            
        }
    }
    public void InitializateUIElements()
    {
        GlobalCore.Instance.UIManagerSkillPanel.InitiatizeSkillPanel();
        GlobalCore.Instance.UIManagerDialogPanel.InitializateDialogPanel();
        GlobalCore.Instance.UIManagerGlobalMap.InitializateGlobalMap();
        GlobalCore.Instance.UIManagerInventory.InitializateInventory();
        GlobalCore.Instance.UIManagerConMenu.InitializateOthers();
        GlobalCore.Instance.UIManagerQuestPanel.InitializateQuestPanel();
    }


    private void HandleUIInput()
    {
        if (Input.GetKeyDown(KeyCode.P))
            ToggleUI(UIManagerQuestPanel.QuestPanel);

        if (Input.GetKeyDown(KeyCode.I))
        {
            if (UIManagerInventory.Inventory.activeSelf == false)
            {
                activeWindow = true;
                GenerateInventory();
            }
            ToggleUI(UIManagerInventory.Inventory);
        }

    //    if (Input.GetKeyDown(KeyCode.M))
    //        ToggleUI(Global.MainGameObjGlobalMapSprite);
    }
    private void GenerateInventory()
    {
        // ���������, ���� �� ���������
        if (UIManagerInventory.InventoryStack == null)
        {
            Debug.LogError("InventoryStack �� ������!");
            return;
        }

        ////foreach (var item in Global.Player.Items)
        ////{
        ////    // �������� ���� � ���������
        ////    Transform slot = Global.MainGameObject.Inventory.InventoryStack.transform.Find($"Cell ({item.Key})");

        ////    if (slot == null)
        ////    {
        ////        Debug.LogWarning($"�� ������ ����: Cell ({item.Key})");
        ////        continue;
        ////    }

        ////    // �������� ���������� � �������� �� ���� ������
        ////    if (!ItemBase.Items.TryGetValue(item.Value.ID, out var itemData))
        ////    {
        ////        Debug.LogError($"������� � ID {item.Value.ID} �� ������ � ���� ������!");
        ////        continue;
        ////    }

        ////    // ������������� ������ � ���������� ���������
        ////    slot.GetComponent<Image>().sprite = itemData.Icon;
        ////    slot.Find("CellText").GetComponent<Text>().text = $"x{item.Value.CurrectStack}";
        ////}
    }




    public GameObject FindChild(GameObject parent, string path)
    {
        Transform child = parent.transform.Find(path);
        return child != null ? child.gameObject : null;
    }

    public void ToggleUI(GameObject uiElement)
    {
        activeWindow = !uiElement.activeSelf;
        uiElement.SetActive(!uiElement.activeSelf);
    }
    public void ShowContextMenu(List<ContextMenuOption> actions, Vector2Int key)
    {
        // 1. ������� ������ ������
        Transform content = UIManagerConMenu.ScrollViewMainMap.transform.Find("Viewport/Content");
        foreach (Transform child in content) Destroy(child.gameObject);

        // 2. ������ ������
        foreach (var action in actions)
        {
            GameObject btn = Instantiate(UIManagerConMenu.MainButton, content);
            btn.SetActive(true);
            btn.name = $"Context_{action.actionType}";
            btn.transform.Find("Text").GetComponent<Text>().text = action.label;

            // 3. ����������� ��������
            ActionType type = action.actionType;
            btn.GetComponent<Button>().onClick.AddListener(() =>
            {
                //ActionExecutor.Instance.Execute(type, key);
                UIManagerConMenu.ScrollViewMainMap.SetActive(false);
            });
        }

        // 4. ���������� ������
        UIManagerConMenu.ScrollViewMainMap.SetActive(true);
    }
}


//    private void Start()
//{
//    InitGlobalVariables();
//    InitGameObjects();
//    InitUI();
//    GenerateWorld();
//}
////private void Update()
////{
////    HandleUIInput();
////    if (!activeWindow)
////    {
////        Global.MainGameObject.Controller.GetComponent<MovePlayer>().MovePlayeronMap();
////        Global.MainGameObject.Controller.GetComponent<InfoObjonMap>().MouseCheck();
////    }
////}
//private void InitGlobalVariables()
//{
//    Global.countSquarepull = 2000;
//    Global.countSpecialpull = 1500;
//    Global.raduisSquarePlayer = 12;
//}
//Global.MainGameObject.Player = FindChild(Canvas, "Player");
//    Global.MainGameObject.InfoPanel = FindChild(Canvas, "InfoPanel");
//////private void GenerateWorld()
//////{
//////    // ������������� ������ ���������
//////    GameObject inventoryStack = Global.MainGameObject.Inventory.InventoryStack;
//////    for (int i = 0; i < inventoryStack.transform.childCount; i++)
//////        Global.ActiveCellsInventory[i] = false;
//////}