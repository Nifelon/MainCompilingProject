using System.Collections.Generic;
using UnityEngine;

public class UIManagerQuestPanel : MonoBehaviour
{
    public static UIManagerQuestPanel Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public static GameObject QuestPanel;
    public static GameObject ScrollViewQuest;
    public static GameObject PanelInfoQuest;
    public void InitializateQuestPanel()
    {
        QuestPanel = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "QuestPanel");
        ScrollViewQuest = GlobalCore.Instance.UIManager.FindChild(QuestPanel, "QuestBackGround/Scroll View");
        PanelInfoQuest = GlobalCore.Instance.UIManager.FindChild(QuestPanel, "QuestBackGround/PanelInfoQuest");
    }

}
