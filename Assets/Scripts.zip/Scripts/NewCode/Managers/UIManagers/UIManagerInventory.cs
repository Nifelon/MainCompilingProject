using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using static GlobalCore;

public class UIManagerInventory : MonoBehaviour

{
    public class InventoryItem
    {
        public ItemsType itemsType;
        public int count;
    }
    public static UIManagerInventory Instance { get; private set; }
    public List<ItemManager.InventoryItem> playerInventory = new List<ItemManager.InventoryItem>(96);
    public GameObject[] inventoryCells;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public static GameObject Inventory;
    public static GameObject PanelEquip;
    public static GameObject InventoryStack;
    public void InitializateInventory()
    {
        Inventory = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "Inventory");
        InventoryStack = GlobalCore.Instance.UIManager.FindChild(Inventory, "InventoryPanel/InventoryStack");
    }
    

    void Start()
    {
        InitializeInventoryCells();
    }

    void InitializeInventoryCells()
    {
        inventoryCells = new GameObject[96];
        for (int i = 0; i < 40; i++)
        {
            inventoryCells[i] = InventoryStack.transform.Find($"Cell ({i})").gameObject;
        }

        // ��������� ��������� ������� ����������
        for (int i = 0; i < 40; i++)
        {
            playerInventory.Add(new ItemManager.InventoryItem(ItemsType.None, 0));
        }
    }
    public void UpdateInventoryUI(int index)
    {
        var item = playerInventory[index];
        var cell = inventoryCells[index];

        Text label = cell.GetComponentInChildren<Text>();
        if (item.itemType != ItemsType.None)
        {
            ItemsData InfoItem= GlobalCore.Instance.ItemManager.ItemsDatabase[item.itemType];
            label.text = $"{InfoItem.Name} x {item.count}";
            cell.GetComponent<Image>().sprite = InfoItem.Icon;
        }
        else
        {
            label.text = "";
        }
    }
}
