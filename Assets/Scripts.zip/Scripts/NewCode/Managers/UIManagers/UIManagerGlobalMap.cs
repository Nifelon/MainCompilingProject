using UnityEngine;
using UnityEngine.SocialPlatforms;
using UnityEngine.UI;

public class UIManagerGlobalMap : MonoBehaviour
{
    public static UIManagerGlobalMap Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    public static GameObject GlobalMap;
    public void InitializateGlobalMap()
    {
        GlobalMap = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "GlobalMap");
    }

    Texture2D GenerateWorldMapTexture()
    {
        Texture2D texture = new(WorldManager.mapSizeX * 2, WorldManager.mapSizeY * 2 + 1);

        for (int x = -WorldManager.mapSizeX; x <= WorldManager.mapSizeX; x++)
            for (int y = -WorldManager.mapSizeY; y <= WorldManager.mapSizeY; y++)
            {
                Vector2Int value = new Vector2Int(x + WorldManager.mapSizeX, y + WorldManager.mapSizeY);
                if (GlobalCore.Instance.PlayerManager.currentGridPos == new Vector2Int(x,y))
                    texture.SetPixel(value.x, value.y, Color.black);
                else
                {
                    var color = GlobalCore.Instance.BiomeManager.GetBiomeColor(GlobalCore.Instance.WorldManager.GlobalMap[new(x, y)].type);
                    texture.SetPixel(value.x, value.y, color);
                }

            }

        texture.Apply();
        return texture;

    }
    public void CreateGlobalMap()
    {
        GlobalMap.GetComponent<RawImage>().texture = GenerateWorldMapTexture();
    }
}

