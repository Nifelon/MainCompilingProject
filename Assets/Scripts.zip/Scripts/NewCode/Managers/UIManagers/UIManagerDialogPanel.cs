using UnityEngine;

public class UIManagerDialogPanel : MonoBehaviour
{
    public static UIManagerDialogPanel Instance { get; private set; }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public static GameObject DialogPanel;
    public static GameObject ScrollViewDialog;
    public static GameObject ImageNPConDialog;
    public static GameObject NameDialog;
    public static GameObject TypeDialog;
    public static GameObject PanelInfoDialog;
    public void InitializateDialogPanel()
    {
        DialogPanel = GlobalCore.Instance.UIManager.FindChild(GlobalCore.Instance.MainGameObjects.Canvas, "DialogPanel");
        NameDialog = GlobalCore.Instance.UIManager.FindChild(DialogPanel, "DialogBackGround/Name");
        TypeDialog = GlobalCore.Instance.UIManager.FindChild(DialogPanel, "DialogBackGround/Type");
        ImageNPConDialog = GlobalCore.Instance.UIManager.FindChild(DialogPanel, "DialogBackGround/RawImage");
        ScrollViewDialog = GlobalCore.Instance.UIManager.FindChild(DialogPanel, "DialogBackGround/Scroll View");
        PanelInfoDialog = GlobalCore.Instance.UIManager.FindChild(DialogPanel, "DialogBackGround/PanelInfoDialog");
    }
}
