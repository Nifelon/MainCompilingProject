using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class UIManagerSkillPanel : MonoBehaviour
{
    public static UIManagerSkillPanel Instance { get; private set; }
    private GameObject SkillPanel;
    //public List<SkillsData> skillsToAssign = new();

    public Dictionary<int, CellSkill> CellsSkill = new();

    private Dictionary<KeyCode, int> hotkeyToSkillSlot = new()
    {
        { KeyCode.Alpha1, 0 },
        { KeyCode.Alpha2, 1 },
        { KeyCode.Alpha3, 2 },
        { KeyCode.Alpha4, 3 },
        { KeyCode.Alpha5, 4 },
        { KeyCode.Alpha6, 5 },
        { KeyCode.Alpha7, 6 },
        { KeyCode.Alpha8, 7 },
        { KeyCode.Alpha9, 8 },
        { KeyCode.Alpha0, 9 }
    };

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        for (int i = 0; i < 10; i++)
        {
            KeyCode key = PlayerSkillManager.defaultKeys[i]; // ������ � KeyCode �� Alpha1 �� Alpha0
            if (Input.GetKeyDown(key))
            {
                PlayerSkillManager.Instance.UseSkill(i);
            }
        }
        foreach (var pair in hotkeyToSkillSlot)
        {
            if (Input.GetKeyDown(pair.Key))
            {
                ActivateSkill(pair.Value);
            }
        }
    }
    public class CellSkill
    {
        public GameObject Cell;
        public Image IconSkill;
        public Text HotKey;
        public GameObject SelectSkill;
        public SkillsData skillData;
        public Image CooldownSprite;
        public Text CoolDownTime;
    }

    public void InitiatizeSkillPanel()
    {
        if (SkillPanel == null)
            SkillPanel = GlobalCore.Instance.MainGameObjects.Canvas.transform.Find("SkillPanel").gameObject;

        for (int i = 0; i < 10; i++)
        {
            GameObject cell = SkillPanel.transform.Find($"Cell ({i})").gameObject;

            CellSkill skill = new CellSkill
            {
                Cell = cell,
                IconSkill = cell.transform.Find("ImageSkill").GetComponent<Image>(),
                HotKey = cell.transform.Find("HotKeySkill").GetComponent<Text>(),
                SelectSkill = cell.transform.Find("SelectedSkill").gameObject,
                CooldownSprite = cell.transform.Find("CooldownSprite").GetComponent <Image>(),
                CoolDownTime = cell.transform.Find("CooldownTime").GetComponent<Text>(),
                skillData = (i < GlobalCore.Instance.PlayerSkillManager.activeSkills.Count) ? GlobalCore.Instance.PlayerSkillManager.activeSkills[i] : null
            };

            KeyCode defaultKey = PlayerSkillManager.defaultKeys[i];
            skill.HotKey.text = FormatKeyCode(defaultKey);

            if (skill.skillData != null)
            {
                skill.IconSkill.gameObject.SetActive(true);
                skill.IconSkill.sprite = skill.skillData.icon;
            }
            else
                skill.IconSkill.gameObject.SetActive(false);

            skill.SelectSkill.GetComponent<Image>().color = Color.white;
            CellsSkill[i] = skill;
        }
    }

    public void ActivateSkill(int index)
    {
        foreach (var skill in CellsSkill.Values)
            skill.SelectSkill.GetComponent<Image>().color = Color.white;

        if (CellsSkill.ContainsKey(index))
            CellsSkill[index].SelectSkill.GetComponent<Image>().color = Color.red;

        Debug.Log($"������������ �����������: {index}");
        // ����� ����� ��������: PlayerSkillSystem.Instance.UseSkill(index);
    }
    private string FormatKeyCode(KeyCode key)
    {
        if (key >= KeyCode.Alpha0 && key <= KeyCode.Alpha9)
            return key.ToString().Replace("Alpha", "");
        return key.ToString();
    }
}