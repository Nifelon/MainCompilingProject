namespace Game.Actors
{
    public enum ActorIdKind { Player, NPC, Creature }
}