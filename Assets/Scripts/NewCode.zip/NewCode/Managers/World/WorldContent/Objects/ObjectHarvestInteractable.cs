﻿// World/WorldContent/Objects/ObjectHarvestInteractable.cs
using UnityEngine;
using Game.World.Objects;

[RequireComponent(typeof(Collider2D))]
public class ObjectHarvestInteractable : MonoBehaviour, IInteractable
{
    [Header("Data")]
    public ObjectData data;        // при спавне можно проставить напрямую; если null — возьмём из SO по типу
    public Vector2Int cell;

    [Header("Items")]
    [SerializeField] private ItemDatabase itemDatabase; // если забыли — подтянем дефолтный из ресурсов

    public string Hint =>
        !string.IsNullOrEmpty(data?.harvest.interactPrompt)
            ? data.harvest.interactPrompt
            : "E — Взять";

    bool _taken;
    ObjectType _originalType;

    void Awake()
    {
        EnsureDataAndItems();
        var wref = GetComponent<WorldObjectRef>();
        _originalType = wref ? wref.type : ObjectType.None;
    }

    void OnEnable()
    {
        // на случай реюза из пула
        _taken = false;
        EnsureDataAndItems();
    }

    void EnsureDataAndItems()
    {
        // 1) если data не проставлена — тянем из ассетов по типу объекта
        if (data == null)
        {
            var wref = GetComponent<WorldObjectRef>();
            if (wref != null)
                data = ObjectDataDB.Get(wref.type); // <-- читаем из твоих SO ассетов
        }

        // 2) itemDatabase — подхватить дефолтный, если поле пустое (ассет должен лежать в Resources/ScriptAssets/Items)
        if (itemDatabase == null)
        {
            // попробуем найти загруженный инстанс
            var found = Resources.FindObjectsOfTypeAll<ItemDatabase>();
            if (found != null && found.Length > 0) itemDatabase = found[0];
            if (itemDatabase == null) itemDatabase = Resources.Load<ItemDatabase>("ScriptAssets/Items/ItemDatabase");
        }
    }

    public void Interact(GameObject actor)
    {
        EnsureDataAndItems();

        if (_taken || data?.harvest == null || !data.harvest.harvestable)
            return;

        _taken = true;

        // 1) ДРОП: читаем из data.harvest.harvestDrops (SO)
        var drops = data.harvest.harvestDrops;
        if (drops != null && drops.Count > 0)
        {
            for (int i = 0; i < drops.Count; i++)
            {
                var d = drops[i];
                if (string.IsNullOrEmpty(d.itemId)) continue;

                int min = Mathf.Min(d.minCount, d.maxCount);
                int max = Mathf.Max(d.minCount, d.maxCount);
                int n = Random.Range(min, max + 1);
                if (n <= 0) continue;

                // enum-путь (Berry/Skin/LeatherPatch) или мост через базу, если имя отличается
                if (System.Enum.TryParse<ItemId>(d.itemId, true, out var eid))
                    InventoryService.Add(eid, n);
                else if (itemDatabase != null)
                    InventoryService.TryAddByName(d.itemId, n, itemDatabase);
                else
                    Debug.LogWarning($"[Harvest] Unknown item '{d.itemId}' and no ItemDatabase assigned.");
            }
        }

        // 2) ПОСЛЕ СБОРА: уничтожить или трансформировать в другой тип (из SO)
        var toType = data.harvest.transformToType;
        if (data.harvest.destroyOnHarvest || toType == ObjectType.None)
        {
            gameObject.SetActive(false);
        }
        else
        {
            var wref = GetComponent<WorldObjectRef>();
            if (wref != null) wref.type = toType;
            gameObject.SetActive(false); // при следующей активации адаптер подтянет визуал нового типа
        }

        // 3) РЕСПАВН (если задан в SO)
        float t = Mathf.Max(0f, data.harvest.respawnSeconds);
        if (t > 0f) StartCoroutine(CoRespawn(t));
    }

    System.Collections.IEnumerator CoRespawn(float delay)
    {
        yield return new WaitForSeconds(delay);

        // вернуть исходный тип (если трансформировали)
        var wref = GetComponent<WorldObjectRef>();
        if (wref != null) wref.type = _originalType;

        _taken = false;
        gameObject.SetActive(true);
    }
}