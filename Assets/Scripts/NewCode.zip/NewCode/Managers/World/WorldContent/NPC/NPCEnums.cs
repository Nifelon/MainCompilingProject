namespace Game.Actors
{
    public enum NPCEnums
    {
        None = 0,
        soldier = 1,
        commander = 2
    }
}