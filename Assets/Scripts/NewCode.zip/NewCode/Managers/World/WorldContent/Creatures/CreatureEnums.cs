namespace Game.Actors
{
    public enum CreatureEnums
    {
        None = 0,
        Wolf = 1,
        Deer = 2
    }
}