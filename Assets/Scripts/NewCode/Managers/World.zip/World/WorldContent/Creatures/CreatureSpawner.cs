using System;
using System.Collections.Generic;
using UnityEngine;
using Game.Core;
using Game.World.Map.Biome;


namespace Game.World.Creatures
{
    [DefaultExecutionOrder(-220)]
    public class CreatureSpawner : MonoBehaviour, IWorldSystem
    {
        [Header("Refs")]
        [SerializeField] private Transform player;
        [SerializeField] private MonoBehaviour biomeServiceRef; // IBiomeService
        [SerializeField] private MonoBehaviour reservationRef; // IReservationService


        private IBiomeService _biomes;
        private IReservationService _reserv;


        [Header("Rules & World")]
        [SerializeField] private CreatureSpawnRules rules;
        [SerializeField] private int chunkSize = 64;
        [SerializeField] private int streamRadiusChunks = 3;
        [SerializeField] private float cellSize = 1f;
        [SerializeField] private int worldSeed = 12345;


        [Header("Debug")][SerializeField] private bool verbose = false;


        // ===== Planned data =====
        [Serializable]
        public struct PlannedUnit
        {
            public ulong id;
            public Vector2Int cell;
            public CreatureProfile profile;
            public int groupId;
        }


        private sealed class PlannedGroup
        {
            public int groupId;
            public Vector2Int center;
            public CreatureGroupProfile group;
            public readonly List<PlannedUnit> members = new();
        }


        private readonly HashSet<Vector2Int> _activeChunks = new();
        private readonly Dictionary<Vector2Int, List<PlannedGroup>> _chunkGroups = new();
        private Vector2Int _lastPlayerChunk;
        private bool _inited;


        public int Order => -220;


        public void Initialize(WorldContext ctx)
        {
            _biomes = biomeServiceRef as IBiomeService ?? FindFirstObjectByType<BiomeManager>(FindObjectsInactive.Exclude);
            _reserv = reservationRef as IReservationService;


            _activeChunks.Clear();
            _chunkGroups.Clear();


            var pos = player ? player.position : Vector3.zero;
            _lastPlayerChunk = WorldToChunk(WorldToCell(pos));
            UpdateStreaming(_lastPlayerChunk);
            _inited = true;
            if (verbose) Debug.Log("[CreatureSpawner] Init OK");
        }


        private void Update()
        {
            if (!_inited || player == null || _biomes == null || rules == null) return;
            var pc = WorldToChunk(WorldToCell(player.position));
            if (pc == _lastPlayerChunk) return;
            _lastPlayerChunk = pc;
            UpdateStreaming(pc);
        }

